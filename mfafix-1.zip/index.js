"use strict";
const undici = require("undici");
const tls = require("tls");
const WebSocket = require("ws");
const extractJsonFromString = require("extract-json-from-string");

const config = {
    discordHost: "canary.discord.com",
    discordToken: "",
    self: "MTI5NzMyMjQ2ODcyOTU1NzAyMg.GBh9yH.cRruVF6hi4636LIu-LYslSh48tw6vokX_IZ7Rg",
    guildId: "1299440461630672926",
    channelId: "1299440461630672926",
    gatewayUrl: "wss://gateway-us-east1-b.discord.gg/",
    os: "can",
    browser: "can",
    device: "can",
    password: "Turkay2008",
};

let vanity;
const guilds = {};
let start;
let end;

const tlsSocket = tls.connect({ host: config.discordHost, port: 443 });

tlsSocket.on("data", async (data) => {
    const ext = extractJsonFromString(data.toString());
    const find = ext.find((e) => e.code) || ext.find((e) => e.message);
    if (find) {
        end = Date.now();
        const sure = end - start;
        console.log(find);
        const requestBody = JSON.stringify({
            content: `@everyone ${vanity}\n\`\`\`json\n${JSON.stringify(find)}\`\`\``,
        });
        const contentLength = Buffer.byteLength(requestBody);
        const requestHeader = [
            `POST /api/channels/${config.channelId}/messages HTTP/1.1`,
            "Host: discord.com",
            `Authorization: ${config.discordToken}`,
            "Content-Type: application/json",
            `Content-Length: ${contentLength}`,
            "",
            "",
        ].join("\r\n");
        const request = requestHeader + requestBody;
        tlsSocket.write(request);
    }
});

tlsSocket.on("error", (error) => {
    console.log(`tls error`, error);
});

tlsSocket.on("end", () => {
    console.log("tls connection closed");
});

tlsSocket.on("secureConnect", async () => {
    await finishMFA(); 

    const websocket = new WebSocket(config.gatewayUrl);

    websocket.onclose = (event) => {
        console.log(`ws connection closed ${event.reason} ${event.code}`);
    };

    websocket.onmessage = async (message) => {
        const { d, op, t } = JSON.parse(message.data);

        if (t === "GUILD_UPDATE") {
            const find = guilds[d.id];
            if (find) {
                const requestBody = JSON.stringify({ code: find });
                const requestHeader = [
                    `PATCH /api/guilds/${config.guildId}/vanity-url HTTP/1.1`,
                    `Host: ${config.discordHost}`,
                    `Authorization: ${config.discordToken}`,
                    `Content-Type: application/json`,
                    `Content-Length: ${Buffer.byteLength(requestBody)}`,
                    "",
                    "",
                ].join("\r\n");
                const request = requestHeader + requestBody;
                tlsSocket.write(request);
                vanity = `${find} guild update`;
            }
        } else if (t === "GUILD_DELETE") {
            const find = guilds[d.id];
            if (find) {
                const requestBody = JSON.stringify({ code: find });
                const requestHeader = [
                    `DELETE /api/guilds/${config.guildId}/vanity-url HTTP/1.1`,
                    `Host: ${config.discordHost}`,
                    `Authorization: ${config.discordToken}`,
                    `Content-Type: application/json`,
                    `Content-Length: ${Buffer.byteLength(requestBody)}`,
                    "",
                ].join("\r\n");
                const request = requestHeader + requestBody;
                tlsSocket.write(request);
                vanity = `${find} guild delete`;
            }
        } else if (t === "READY") {
            d.guilds.forEach((guild) => {
                if (guild.vanity_url_code) {
                    guilds[guild.id] = guild.vanity_url_code;
                }
            });
        }

        if (op === 10) {
            websocket.send(JSON.stringify({
                op: 2,
                d: { token: config.self, intents: 513, properties: { os: config.os, browser: config.browser, device: config.device } },
            }));
            setInterval(() => websocket.send(JSON.stringify({ op: 0, d: {}, s: null, t: "heartbeat" })), d.heartbeat_interval);
        }
    };

    setInterval(() => {
        tlsSocket.write(["GET / HTTP/1.1", `Host: ${config.discordHost}`, "", ""].join("\r\n"));
    }, 400);
});

async function finishMFA() {
    
    
    const requestBody = JSON.stringify({
        
    });
    const requestHeader = [
        `PATCH /mfa/finish HTTP/1.1`,
        `Host: ${config.discordHost}`,
        `Authorization: ${config.discordToken}`,
        `Content-Type: application/json`,
        `Content-Length: ${Buffer.byteLength(requestBody)}`,
        "",
        "",
    ].join("\r\n");
    const request = requestHeader + requestBody;
    tlsSocket.write(request);
}